
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/asana-task.mjs
var PROJECT_GID = "1213469898633453";
var ASANA_BASE = "https://app.asana.com/api/1.0";
var asana_task_default = async (req) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  const token = Netlify.env.get("ASANA_TOKEN");
  if (!token) return new Response(JSON.stringify({ error: "ASANA_TOKEN not configured" }), { status: 500, headers });
  const { title, assignee, kpi, root_cause } = await req.json();
  let sectionGid = null;
  try {
    const sectionsRes = await fetch(`${ASANA_BASE}/projects/${PROJECT_GID}/sections`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const sections = await sectionsRes.json();
    const bomSection = (sections.data || []).find((s) => s.name.toLowerCase().includes("bom review"));
    if (bomSection) sectionGid = bomSection.gid;
  } catch (e) {
  }
  const taskData = {
    data: {
      name: title,
      notes: `Root Cause: ${root_cause}
KPI: ${kpi || "TBD"}

Created from Inventory War App`,
      projects: [PROJECT_GID],
      assignee: assignee || null
    }
  };
  try {
    const taskRes = await fetch(`${ASANA_BASE}/tasks`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(taskData)
    });
    const task = await taskRes.json();
    if (task.data && task.data.gid) {
      if (sectionGid) {
        await fetch(`${ASANA_BASE}/sections/${sectionGid}/addTask`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ data: { task: task.data.gid } })
        });
      }
      return new Response(JSON.stringify({ ok: true, task_gid: task.data.gid, task_url: task.data.permalink_url }), { headers });
    }
    return new Response(JSON.stringify({ error: "Failed to create task", details: task }), { status: 500, headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
};
var config = { path: "/api/asana-task" };
export {
  config,
  asana_task_default as default
};
