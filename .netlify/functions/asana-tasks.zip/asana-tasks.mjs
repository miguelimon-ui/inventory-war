
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/asana-tasks.mjs
var PROJECT_GID = "1213469898633453";
var ASANA_BASE = "https://app.asana.com/api/1.0";
var asana_tasks_default = async (req) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Content-Type": "application/json"
  };
  const token = Netlify.env.get("ASANA_TOKEN");
  if (!token) return new Response(JSON.stringify({ error: "ASANA_TOKEN not configured" }), { status: 500, headers });
  try {
    const sectionsRes = await fetch(`${ASANA_BASE}/projects/${PROJECT_GID}/sections`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    const sections = await sectionsRes.json();
    const bomSection = (sections.data || []).find((s) => s.name.toLowerCase().includes("bom review"));
    let tasks = [];
    const sectionGid = bomSection ? bomSection.gid : null;
    const tasksUrl = sectionGid ? `${ASANA_BASE}/sections/${sectionGid}/tasks?opt_fields=name,completed,due_on,assignee.name,notes,permalink_url,num_subtasks` : `${ASANA_BASE}/projects/${PROJECT_GID}/tasks?opt_fields=name,completed,due_on,assignee.name,notes,permalink_url,num_subtasks`;
    const tasksRes = await fetch(tasksUrl, { headers: { "Authorization": `Bearer ${token}` } });
    const tasksData = await tasksRes.json();
    tasks = tasksData.data || [];
    for (const task of tasks) {
      try {
        const storiesRes = await fetch(`${ASANA_BASE}/tasks/${task.gid}/stories?opt_fields=text,created_by.name,created_at,type`, {
          headers: { "Authorization": `Bearer ${token}` }
        });
        const storiesData = await storiesRes.json();
        task.comments = (storiesData.data || []).filter((s) => s.type === "comment").map((s) => ({ text: s.text, author: s.created_by?.name || "Unknown", date: s.created_at }));
      } catch (e) {
        task.comments = [];
      }
    }
    return new Response(JSON.stringify({ tasks, section: bomSection ? bomSection.name : "All Tasks" }), { headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
};
var config = { path: "/api/asana-tasks" };
export {
  config,
  asana_tasks_default as default
};
