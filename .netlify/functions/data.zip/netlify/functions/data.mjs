
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/data.mjs
import { getStore } from "@netlify/blobs";
var data_default = async (req, context) => {
  const store = getStore("inventory-war");
  const url = new URL(req.url);
  const key = url.searchParams.get("key");
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, PUT, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }
  if (req.method === "GET" && !key) {
    const { blobs } = await store.list();
    return new Response(JSON.stringify({ keys: blobs.map((b) => b.key) }), { headers });
  }
  if (req.method === "GET" && key) {
    const data = await store.get(key, { type: "json" });
    if (!data) {
      return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers });
    }
    return new Response(JSON.stringify(data), { headers });
  }
  if (req.method === "PUT" && key) {
    const body = await req.json();
    await store.setJSON(key, body);
    return new Response(JSON.stringify({ ok: true, key }), { headers });
  }
  return new Response(JSON.stringify({ error: "bad request" }), { status: 400, headers });
};
var config = {
  path: "/api/data"
};
export {
  config,
  data_default as default
};
